var mysql = require("mysql");
const config = require('./config/config');
const logger = require('./config/logger').winston;
const express = require('express');
var app = express();
var cors = require('cors');


const bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
module.exports.jsonBodyParser = bodyParser;

//cors code starts//
app.use(cors());
app.use(function(req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST');
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type, Authorization');
    next();
});


//include all the controllers//
var lineMap=require("./map/map");

//call the post or get services//
app.post("/addMapDetails",lineMap.addMapDetails);
app.get("/getMapDetails",lineMap.getMapDetails);

//listen the port//
  var server = app.listen(config.SERVER_PORT, function() {
    logger.info("Server running on %s:%s", server.address().address, server.address().port);
  });


