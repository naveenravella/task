var mysql = require("mysql");
   
module.exports = {
    
  LOGGING_DIR: "logs",
  MODE: "development",
  SERVER_PORT: "3005",
    
    con : mysql.createConnection({
    host: "localhost",
    port: "3306",
    user: "root",
    password: "",
    database: "linemap",
    multipleStatements: true
    }),
  server_path:"http://localhost:3005/",
  
   //Http Codes
  
  "BadRequest": 400,
  "OK": 200,
  "NoContent": 204,
  "ServerError": 500,
  "AuthenticationError": 401,
  "AlreadyExists":409,
  "Created":201,
  "conflict":409,
  "NoAccess":403,    
  
}
