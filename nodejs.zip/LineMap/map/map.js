const config = require('../config/config');
const logger = require('../config/logger').winston;

//var moment = require('moment');

module.exports = {
    
// add map details code starts
    
addMapDetails : function(request,response){
     
    var mapDetails=[];
    if(!request.body) {
      return response.status(config.BadRequest).send({message: "Map Details required"});
    }else{
       mapDetails= request.body;
    }
         config.con.query("call deleteMapDetails()",function(err,result){
                if(err){
                    logger.error(err); 
                    return response.status(config.ServerError).send({"message":"Internal server error"});
                }
        for(var i=0,m=0;i<mapDetails.length;i++){
            m++;
			var mapLength=mapDetails.length;
             var n=0;
            for(var j=0;j<mapDetails[i].length;j++){
				var innerLength=mapDetails[i].length;
                config.con.query("call addMapDetails(?,?,?)",[m,mapDetails[i][j].year,mapDetails[i][j].score],function(err,result1){
                if(err){
                    logger.error(err); 
                    return response.status(config.ServerError).send({"message":"Internal server error"});
                }
                n++;
                if(m==mapLength && n==innerLength){
                  return response.status(config.OK).send(); 
                }
            
                });
            }
         
        }
        });
     
 },
    
// get map details code starts
    
getMapDetails : function(request,response){
     
    config.con.query("call getMapDetails()",function(err,result){
        if(err){
            logger.error(err); 
            return response.status(config.ServerError).send({"message":"Internal server error"});
        }
        var mapScores=[];
        var score=[];
        var j=result[1][0].rowNumber;
        for(var i=0,startYear=result[0].minYear;i<result[1].length;i++){
            if(j==result[1][i].rowNumber){
                score.push({"year": result[1][i].year, "score": result[1][i].score});
            }else{
                j++;
                 mapScores.push(score);
                 score=[];
                score.push({"year": result[1][i].year, "score": result[1][i].score});
            }  
        }
        mapScores.push(score);
        var mapResults={
            "mapConstraints":result[0][0],
            "mapScores":mapScores
        }
         return response.status(config.OK).send(mapResults); 
               
      });
           
     
 },
  
    
};