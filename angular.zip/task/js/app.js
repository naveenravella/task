(function () {
  'use strict';
var app=angular.module('task',['chartjs-directive']);//intialization of angular app
//csv upload controller 
app.controller('csvUploadCtrl',['$http','$scope','$rootScope',function($http,$scope,$rootScope){
    //get the uploaded csv data using $on method//
    $scope.$on("fileSelected",function(event,args){
          $scope.invalidFormat='';
          $scope.chartView=false;
          $scope.chartError='';
          var csvInput=event.targetScope.fileReader; 
          if(csvInput=='Invalid format'){
              $scope.invalidFormat='Please select valid format';
              return;
          }
          // split content based on new line
			var allTextLines = csvInput.split(/\r\n|\n/);
            $scope.totalseries=[];
            var data;
            var delimiterValue; 
			 for(var i = 0; i < (allTextLines.length); i++){
					data = allTextLines[i].split(',');
					$scope.seriesarray = [];
				for(var j = 1; j < data.length; j++){
                    delimiterValue=data[j].split('|');
					$scope.seriesarray.push({"year":delimiterValue[0],"score":delimiterValue[1]});
				}
                 if($scope.seriesarray.length>0){
                     $scope.totalseries.push($scope.seriesarray);
                 }
				
			}
           
        
    });
    //upload csv file//
    $scope.uploadCsv = function(){
        if(!$scope.totalseries){
            $scope.invalidFormat='Upload the csv file';
            return;
        }
         $http
				.post(
					  'http://localhost:3005/addMapDetails',$scope.totalseries).success(
							function(data,status) {
								$scope.chartView=true;
                                $scope.totalseries=[];
							}).error(function(data, status,headers, config){
								$scope.chartError='Error occured while upload the csv file';	
							});
    }
    //get dataset code starts//
     $scope.displayDataSet = function(){
         $http.get('http://localhost:3005/getMapDetails').success(function(data,status){
             $scope.yearStart=data.mapConstraints.minYear;
             $scope.yearEnd=data.mapConstraints.maxYear;
             $scope.yearsArray=[];
             for(var x=$scope.yearStart;x<=$scope.yearEnd;x++){
                 $scope.yearsArray.push(x);
             }
             //colors array//
             $scope.colors=['220,220,220','151,187,205','212, 235, 255','216, 247, 255'];
              $scope.dataArray=[];
                 for(var j=0;j<data.mapScores.length;j++){
                     var i=$scope.yearStart;
                     $scope.rowValues=[];
                    for(i;i<=$scope.yearEnd;i++){ 
                        var y=0,z=0;
                     for(var k=0;k<data.mapScores[j].length;k++){
                         if(i==data.mapScores[j][k].year){
                             y++;
                             z=data.mapScores[j][k].score;
                          }
                     }
                     if(y>0){
                         $scope.rowValues.push(z);
                     }else{
                         $scope.rowValues.push(0);
                     }    
                 }
                 $scope.dataArray.push(
                     {
                       fillColor : 'rgba('+$scope.colors[j]+',0.5)',
                       strokeColor : 'rgba('+$scope.colors[j]+',1)',
                       pointColor : 'rgba('+$scope.colors[j]+',1)',
                       pointStrokeColor : "#fff",
                       data : $scope.rowValues
                     }); 
             }
             var data = {
            labels : $scope.yearsArray,
            datasets : $scope.dataArray
          };
          $scope.myChart = {"data": data, "options": {} };
         }).error(function(data,status){
             $scope.chartError='Error occured while fetching the data';
         });
           
     }
}]);
//declare the csv file reader directive//
app.directive('fileReader', function() {
	  return {
				scope: {
				  fileReader:"="
				},
			link: function(scope, element) {
				 $(element).on('change', function(changeEvent) {
				   var files = changeEvent.target.files,
                       ext=files[0].name.substring(files[0].name.lastIndexOf('.') + 1).toLowerCase();
                    if(ext=='csv'){
				   if (files.length) {
				   var r = new FileReader();
				   r.onload = function(e) {
				   var contents = e.target.result;
				   scope.$apply(function () {
				      scope.fileReader = contents;
		                  scope.$emit("fileSelected", { contents: contents });
				      });
				   };    
				 r.readAsText(files[0]);
			    }
              }else{
                 scope.$apply(function () {
				      scope.fileReader = 'Invalid format';
		                  scope.$emit("fileSelected", { contents: scope.fileReader });
				      }); 
              }
			});
		  }
	  };
});
 })();    