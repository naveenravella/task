const winston = require('winston');
const fs = require('fs');
const config = require('./config');

// Create the log directory if it does not exist
if (!fs.existsSync(config.LOGGING_DIR)) {
  fs.mkdirSync(config.LOGGING_DIR);
}

const tsFormat = () => (new Date()).toISOString()
            .replace(/T/, ' ')        // replace T with space
            .replace(/\..+/, '');    // delete the dot and everything after

var logger = new (winston.Logger)({
  transports: [
    new (winston.transports.Console)({
      name: 'console',
      timestamp: tsFormat,
      colorize: true,
      level: 'info'
    }),
    new (require('winston-daily-rotate-file'))({
      name: 'error-file',
      filename: `${config.LOGGING_DIR}/-error.log`,
      level: 'error',
      timestamp: tsFormat,
      datePattern: 'yyyy-MM-dd',
      prepend: true,
      colorize: true
    }),
    new (require('winston-daily-rotate-file'))({
      name: 'debug-file',
      filename: `${config.LOGGING_DIR}/-info.log`,
      level: 'info',
      timestamp: tsFormat,
      datePattern: 'yyyy-MM-dd',
      prepend: true,
      colorize: true
    })
  ]
});

// if(process.env.GREETIN_MODE == 'production') {
if(config.MODE == 'production') {
  logger.remove('console');     //Forbid console logging in production
}
module.exports.winston = logger;
